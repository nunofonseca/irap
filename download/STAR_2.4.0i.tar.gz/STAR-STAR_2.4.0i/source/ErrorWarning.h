#ifndef DEF_ErrorWarning
#define DEF_STATS

#include "IncludeDefine.h"
#include "Parameters.h"

void exitWithError(string messageOut, ostream &streamOut1, ostream &streamOut2, int errorInt, Parameters &P);
#endif
