#define _USE_KNETFILE
#define BGZF_CACHE
#define BGZF_MT
