#ifndef CODE_GlobalVariables
#define CODE_GlobalVariables
Stats g_statsAll;//global mapping statistics
ThreadControl g_threadChunks;
#endif
