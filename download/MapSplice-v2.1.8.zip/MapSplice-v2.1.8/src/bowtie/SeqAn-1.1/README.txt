This is SeqAn, the C++ template library for sequence analysis

See http://www.seqan.de for more information

Read "docs/Page_Installation.html" for detailed installation instructions.


Folders:
========

"seqan": SeqAn library (add the folder that contains "seqan" to 
         your include path)
"demos": SeqAn demos, see also "docs/INDEXPAGE_Demo.html"
"apps":  SeqAn applications
"docs":  HTML-Documentation


Files:
======

"Makefile": make file for Linux/Darwin/Solaris
"*_7.sln", "*_7.vcproj": Visual Studio .net 2003 solution and project files
"*_8.sln", "*_8.vcproj": Visual Studio .net 2005 solution and project files
"*_9.sln", "*_9.vcproj": Visual Studio .net 2008 solution and project files


Have fun!

Your SeqAn Team
