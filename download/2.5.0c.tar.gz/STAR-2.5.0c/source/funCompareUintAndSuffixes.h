#ifndef CODE_funCompareUintAndSuffixes
#define CODE_funCompareUintAndSuffixes

extern char* globalGenomeArray;
int funCompareUintAndSuffixes ( const void *a, const void *b);

#endif
