#!/bin/bash

TEST_FILE=$1

R --slave <<-EOF
        Rprof("test_prof.out",memory.profiling=TRUE)
	library('RUnit')
        source("../R/emBAM.R")
	res <- runTestFile('${TEST_FILE}',
		rngKind='default', rngNormalKind='default')
	printTextProtocol(res, showDetails=FALSE)
        Rprof(NULL)
        summaryRprof("test_prof.out")
#,memory='both')
EOF
