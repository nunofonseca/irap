#!/bin/bash

TEST_FILE=$1

R --slave <<-EOF
	library('RUnit')
	source("../R/emBAM.R")
	res <- runTestFile('${TEST_FILE}',
                                   testFuncRegexp = "^test.+",
		rngKind='default', rngNormalKind='default')
	printTextProtocol(res, showDetails=FALSE)
EOF
