double digama ( double x, int *ifault );

