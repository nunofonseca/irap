
#define BUFFER_DEFAULT 20000

bool transposeFiles(vector<string> inFileNames, string outFileName, bool verbose, string message = "");
