package edu.uconn.engr.dna.isoem;

import edu.uconn.engr.dna.format.Clusters;
import edu.uconn.engr.dna.format.Isoforms;
import edu.uconn.engr.dna.io.GTFParser;
import edu.uconn.engr.dna.io.GenesAndIsoformsParser;
import edu.uconn.engr.dna.util.Pair;
import edu.uconn.engr.dna.util.ParameterRunnable;
import edu.uconn.engr.dna.util.ParameterRunnableFactory;
import edu.uconn.engr.dna.util.Utils;

import java.io.*;
import java.util.List;

public class ConvertSamFromIsoformToGenomeCoord {

	public static void main(String[] args) throws Exception {
                Integer polyATailLen = 0;
		if (args.length < 2 || args.length > 3) {
			System.out.println("Usage: isoformsGTF outputSam [polyATailLength]");
			System.exit(1);
		}

		GenesAndIsoformsParser giParser = new GTFParser();
		Pair<Clusters, Isoforms> p = giParser.parse(new FileInputStream(args[0]));
		Isoforms isoforms = p.getSecond();
//sahar debug
//                System.err.println("before Adding fake polyA tail exons length of NR_003363 = "+isoforms.getValue("NR_003363").getExons().size());

		Reader samInIsoCoord;
		int buffSize = 1 << 16;
		samInIsoCoord = new BufferedReader(new InputStreamReader(System.in), buffSize);

		Writer samInGenomeCoord;
		samInGenomeCoord = new BufferedWriter(new FileWriter(args[1]), buffSize);

		if (args.length > 2) {
			polyATailLen = Integer.parseInt(args[2]);
			Utils.addFakePolyAToExons(isoforms, polyATailLen.intValue());
		}

//sahar debug
//                System.err.println("after Adding fake polyA tail exons length of NR_003363 = "+isoforms.getValue("NR_003363").getExons().size());
		int nThreads = Runtime.getRuntime().availableProcessors();
//		int nThreads = 1 ;//Runtime.getRuntime().availableProcessors();
		new ThreadPooledSamParser<Void>(
						nThreads, Math.max(10, 3 * nThreads),
						1 << 16, ParameterRunnableFactory.instance(IsoToGenomeParameterRunnable.class,
						isoforms, samInGenomeCoord, polyATailLen)).parse(samInIsoCoord);
		samInGenomeCoord.close();
	}

	public static class IsoToGenomeParameterRunnable implements ParameterRunnable<List<String>, Void> {

		private SamIsoformToGenomeConverter isoToGenomeConverter;
		private DuplicatesRemovingConverter duplicatesRemovingConverter;
		private final Writer out;

		public IsoToGenomeParameterRunnable(Isoforms isoforms, Writer out) {
			this.out = out;
			isoToGenomeConverter = new SamIsoformToGenomeConverter(
							isoforms);
			duplicatesRemovingConverter = new DuplicatesRemovingConverter();
		}

		public IsoToGenomeParameterRunnable(Isoforms isoforms, Writer out, Integer polyAtail) {
			this.out = out;
			isoToGenomeConverter = new SamIsoformToGenomeConverter(
							isoforms, polyAtail.intValue());
			duplicatesRemovingConverter = new DuplicatesRemovingConverter();
		}

		@Override
		public void run(List<String> item) {
			int j = 0;
			synchronized (item) {
				for (int i = 0, n = item.size(); i < n; ++i) {
					String s = item.get(i);
					if (s == null || s.startsWith("@")) {
						continue;
					}

					try {
						//System.out.println("converting line " + s);
						s = isoToGenomeConverter.convert(s);
					} catch (Exception e) {
						System.err.println("Error converting line " + s);
						e.printStackTrace();
//sahar debug; exit if error occurs
//						return;						
					}
					if (s != null) {
						//System.out.println("converted to " + s);
						s = duplicatesRemovingConverter.convert(s);
						if (s != null) {
							//System.out.println("not a duplicate " + s);
							item.set(j++, s);
						}
					}
				}
			}
			synchronized (out) {
				try {
					for (int i = 0; i < j; ++i) {
						out.write(item.get(i));
						out.write('\n');
					}
					out.flush();
				} catch (IOException e) {
					e.printStackTrace();
					System.exit(1);
				}
			}
			duplicatesRemovingConverter.clear();
		}

		@Override
		public Void done() {
			return null;
		}
	}
}
