package edu.uconn.engr.dna.isoem;

public enum CoordType {
    START, END;
}
