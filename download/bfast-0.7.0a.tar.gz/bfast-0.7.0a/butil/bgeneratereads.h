#ifndef BGENERATEREADS_H_
#define BGENERATEREADS_H_

#include "../bfast/RGBinary.h"

void GenerateReads(RGBinary*, int, int, int, int, int, int, int, int, int, int);
void GenerateReadsFP(RGBinary*, int, int, int, int, int, int, int, int, int, int, int, FILE*);
#endif
