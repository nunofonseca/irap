#ifndef BREPEAT_H_
#define BREPEAT_H_

#define MAX_UNIT_LENGTH 2048
#define BREPEAT_ROTATE_NUM 1000

#endif
