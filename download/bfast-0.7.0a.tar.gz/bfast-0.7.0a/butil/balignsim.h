#ifndef BALIGNSIM_H_
#define BALIGNSIM_H_

void Run(RGBinary*, char*, int, int, int, int, int, int, int, int, int, int, char*);

#endif
