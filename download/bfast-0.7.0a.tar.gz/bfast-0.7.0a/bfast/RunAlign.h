#ifndef RUN_ALIGN_H_
#define RUN_ALIGN_H_

void RunAlign(char*, char*, int, int, int, char*, int);

#endif
