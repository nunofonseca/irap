#ifndef RGINDEXLAYOUT_H_
#define RGINDEXLAYOUT_H_

#include "BLibDefinitions.h"

/* TODO */
void RGIndexLayoutCreate(char*, int32_t, int32_t, RGIndexLayout*);
void RGIndexLayoutDelete(RGIndexLayout*);

#endif
