package edu.uconn.engr.dna.probability;

public abstract class CumulativeProbabilityDistribution extends ProbabilityDistribution {

	public abstract double cumulativeLowerTail(int r);

}
