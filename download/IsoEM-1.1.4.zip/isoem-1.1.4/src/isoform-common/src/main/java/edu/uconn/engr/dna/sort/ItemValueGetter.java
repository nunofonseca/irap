package edu.uconn.engr.dna.sort;

public interface ItemValueGetter<T> {

	int getNumber(T item);
}
