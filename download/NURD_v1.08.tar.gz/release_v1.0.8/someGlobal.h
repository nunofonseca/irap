#ifndef SOMECONST_H_INCLUDED
#define SOMECONST_H_INCLUDED

#include <vector>
#include <string>
using namespace std;

extern const double epsilon;
extern const double maxFloat;
extern const int max_iteration;

extern int bin_N;
extern vector<double> bin;

typedef int _chr_coor;

#endif // SOMECONST_H_INCLUDED
