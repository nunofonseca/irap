#include <time.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include "myFunction.h"

#include <unistd.h> // parsing argument
#include <sys/stat.h> 	// mkdir and access 
#include <errno.h> 	// error information
#include <string.h>	// strerror

using namespace std;

bool std_output_with_time(string s)
{
    time_t cur_time;
    time(&cur_time);
    printf("[%15.15s]:\t%s",ctime(&cur_time)+4,s.c_str());
}

// get the name of sam file.
// take both linux and windows into consider.
string get_file_name(const string& dir, int& flag){
	flag = 0;
	if(dir.size()>0){
		if( dir[dir.size() - 1] == '\\' || dir[dir.size() - 1] == '/' ){
			flag = 1;
			cout<<"fatal error!"<<endl; // should throw some exception.
			return "";
		}
		size_t length = 0;
		int i = dir.size() - 1;
		for(; i>=0 ; i--){
			if( dir[i] == '\\' || dir[i] == '/' ){
				break;
			}
			length++;
		}
		return dir.substr(i+1,length);
	}
	else{
		flag = 2;
		return "";
	}
}

// create directory.
int create_dir(const string&  dirName)
{
	string dir = dirName + "/";
	
	for( int i=1;   i<dir.length();   i++)
	{
		if(dir[i]=='/')
		{
			dir[i] = 0;
  			if( access(dir.c_str(), F_OK) != 0 )
  			{
      			if(mkdir(dir.c_str(), 0755)==-1) // mode 755 means: rwxr-xr-x
				{
					return   -1;
				}
			}
			dir[i] = '/';
		}
	}
	return   0;  
} 
