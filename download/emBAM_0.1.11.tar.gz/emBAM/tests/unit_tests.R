library(RUnit)
library(emBAM)

testsuite.emBAM <- defineTestSuite("emBam.tests",
                                   dirs = paste(getwd(),"/unit",sep=""),
                                   testFileRegexp = "*.unit.test.R$",
                                   testFuncRegexp = "^test.+",
                                   rngKind = "Marsaglia-Multicarry",
                                   rngNormalKind = "Kinderman-Ramage")
testResult <- runTestSuite(testsuite.emBAM)
printTextProtocol(testResult)
## runTestFile(file.path(.path.package(package="RUnit"),
## "examples/runitc2f.r"))
