readmmseq <- function( mmseq_files = grep("gene|identical", dir( pattern="\\.mmseq$" ), value=TRUE, invert=TRUE),
		 sample_names = sub("\\.mmseq","", mmseq_files), normalize=TRUE, partition="", common_set=NULL) {
	
	cat( "Using mmseq files:\n", paste("\t", mmseq_files, sep="", collapse="\n"), "\n") 
	cat( "Using sample names:\n", paste("\t", sample_names, sep="", collapse="\n"), "\n") 
	if( length(mmseq_files) == 0 || length(sample_names)  != length(mmseq_files) ) {
		cat( "ERROR:\n\tplease define mmseq files and sample names for each file.\n" )
		return(NULL)
	}
	
	# read in mmseq data
	mu = c()
	sd = c()
	mcse = c()
  iact = c()
	effective_lengths = c()
	true_lengths = c()
  n_reads <- c()
  unique_hits <- c()
  ntranscripts<- c()
  observed<- c()
  dup_sample_names <- c()
	cat( "Reading mmseq output files\n" )
	for( i in 1:length(mmseq_files) ) {
		dat = read.table( mmseq_files[i], header=TRUE, stringsAsFactors=FALSE, sep="\t")
    if(! any(colnames(dat)=="log_mu") ||
       ! any(colnames(dat)=="sd") || 
       ! any(colnames(dat)=="mcse") || 
       ! any(colnames(dat)=="iact") || 
       ! any(colnames(dat)=="unique_hits") ||
       ! any(colnames(dat)=="ntranscripts") ||
       ! any(colnames(dat)=="observed") ||
       ! any(colnames(dat)=="effective_length") ||
       ! any(colnames(dat)=="true_length")) {
      stop("Colnames must contain log_mu, sd, mcse, iact, effective_length, true_length, ntranscripts, observed and unique_hits.")
    }
    spl = strsplit(partition, "|", fixed=TRUE)[[1]]
    if(length(spl)==0) spl=".*"
    if(length(spl)>0 && any(spl=="")) {
      stop("Cannot split using empty string.")
    }
    x=grep(spl[1], dat[,grepl("id", colnames(dat))]) 
    if(length(x)==0) spl=".*" # not a sample to partition

    for(p in spl) {
      cat("\t", mmseq_files[i], "(",p, ")","\t",sep="")
      dup_sample_names <- c(dup_sample_names, sample_names[i])
      if(p != ".*") dup_sample_names[length(dup_sample_names)] = paste(dup_sample_names[length(dup_sample_names)], p,sep="")

      x=grepl(p, dat[,grepl("id", colnames(dat))])
      if(!is.null(common_set)) {
        if(p != ".*") {
        #  x = x & sub(p, "", dat[,grepl("id", colnames(dat))]) %in% common_set
          x = match(common_set, sub(p, "", dat[, grepl("id", colnames(dat))]))
        } else {
        #  x = x & dat[,grepl("id", colnames(dat))] %in% common_set
          x = match(common_set, dat[,grepl("id", colnames(dat))])
        }
      }

      mu <- cbind(mu, dat$log_mu[x])
      sd <- cbind(sd, dat$sd[x])
      mcse <- cbind(mcse, dat$mcse[x])
      iact<- cbind(iact, dat$iact[x])
      unique_hits <- cbind(unique_hits, dat$unique_hits[x])
      ntranscripts<- cbind(ntranscripts, dat$ntranscripts[x])
      observed <- cbind(observed, dat$observed[x])
      effective_lengths <- cbind(effective_lengths, dat$effective_length[x])
      true_lengths <- cbind(true_lengths, dat$true_length[x])
      if(i==1) {
        rownames(mu) = rownames(sd) = rownames(mcse)= rownames(iact) = rownames(unique_hits)=rownames(ntranscripts)=rownames(observed)=rownames(true_lengths)=rownames(effective_lengths)=
          sub(partition, "", dat[x,grepl("id", colnames(dat))])
      } else {
        if(! all(rownames(mu) == sub(partition, "", dat[x,grepl("id", colnames(dat))]) )) {

          stop("Attempting to join incompatible mmseq files (different features).\n")
        }
      }
      ta <- readLines(mmseq_files[i], n=100) # header should be no more than 100 lines
      ta <- strsplit(ta[grep("# Mapped fragments", ta)], " ")[[1]]
      n_reads <- c(n_reads, as.numeric(ta[length(ta)]))
      cat( "found", n_reads[length(n_reads)], "aligned reads (or read pairs)\n" )
    }
  }
  colnames(mu)=colnames(sd)=colnames(mcse)=colnames(iact)=colnames(unique_hits)=colnames(ntranscripts)=colnames(observed)=colnames(effective_lengths)=colnames(true_lengths)=dup_sample_names
  names(n_reads) <- dup_sample_names

  if(!all(is.na(true_lengths)) && any(apply(true_lengths,1, function(x) { !all(x==x[1])}))) {
    warning("True transcript lengths differ across files.\n")
  }

  # un-log the estimates 
  cat( "Unlogging and unstandardising the estimates\n" )
  counts = exp(1)^(mu)
  
  # multiply by library size
  counts= sapply( colnames(counts), function(x) { counts[,x]*n_reads[x] })
  rownames(counts)=rownames(mu)

  # multiply by transcript length and divide by 10^9
  counts = sapply( colnames(mu), function(x) { counts[,x] = (counts[,x]*effective_lengths[,x])/(1e3*1e6) } )
  counts[is.na(counts)] = 0 # the ones that had no expression in MMSEQ
	
  if(normalize && ncol(mu)>1) {
    cat("Normalizing expression estimates with log factors:\n")
    minfrac = max(0.2, (ncol(mu) - floor(ncol(mu)^2/160))/ncol(mu))
    cat("Min frac: ", minfrac, "\n")
    uh = apply(unique_hits,1,function(x){sum(x>=1) >= minfrac*length(x) })
    sf <- apply(mu[uh,] - rowMeans(mu[uh,], na.rm=TRUE) ,2, function(x){median(x[is.finite(x)])})
    for(i in 1:length(sf)) {
      mu[,i] <- mu[,i] - sf[i]
      cat("\t", dup_sample_names[i],"\t", signif(sf[i],4),"\n")
    }
    cat("Normalizing counts with factors:\n")
    sf <- apply(log(counts[uh,]) - rowMeans(log(counts[uh,]), na.rm=TRUE), 2, function(x){median(x[is.finite(x)])})
    for(i in 1:length(sf)) {
      counts[,i] <- counts[,i]/exp(sf)[i]
      cat("\t", dup_sample_names[i],"\t", signif(exp(sf[i]),4),"\n")
    }
  }
  
  return(list(log_mu=mu, sd=sd, mcse=mcse, iact=iact, effective_length=effective_lengths, true_length=true_lengths, unique_hits=unique_hits, ntranscripts=ntranscripts[,1], observed=observed, counts=counts))
}


