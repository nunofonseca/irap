#include "Parameters.h"

void genomeGenerate(Parameters *P);

