#ifndef DEF_streamFuns
#define DEF_streamFuns
unsigned long long fstreamReadBig(std::ifstream &S, char* A, unsigned long long N);
void fstreamWriteBig(std::ofstream &S, char* A, unsigned long long N);
#endif
