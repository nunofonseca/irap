#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <fstream>
#include <stdlib.h>
#include <algorithm>
#include <sstream>
#include "delimiter.h"
#include "myAlgorithm.h"
#include "myFunction.h"

#include <unistd.h> // parsing argument
#include <sys/stat.h> 	// mkdir and access
#include <dirent.h> // directory operation
#include <errno.h> 	// error information
#include <string.h>	// strerror
#include <stdexcept>

// the header of expression estimation
#include "myClass.h"
#include "myData.h"
#include <time.h>

using namespace std;

void usage()
{
	cout<<"NURD is a tool to estimate isoform expression with RNA-Seq data."<<endl;
	cout<<"Version: 1.0.8"<<endl;
	cout<<"========================================"<<endl;
	cout<<"Usage:\t"<<"NURD [options] <-G annotation.gtf>|<-R annotation.refflat> <-S mapping_file.sam>"<<endl;
	cout<<"\t"<<"-G: annotation.gtf: gene annotation in gtf format."<<endl;
	cout<<"\t"<<"-R: annotation.refflat: gene annotation in refflat format."<<endl;
	cout<<"\t"<<"-S: mapping_result.sam: reads mapping result in sam format."<<endl;
	cout<<"========================================"<<endl;
	cout<<"\t"<<"Optional:"<<endl;
	cout<<"\t"<<"-A: the weight of GBC when mixturing the GBC and LBC into one gene structure matrix. It's a float number between 0-1. Default: 0.5"<<endl;
	cout<<"\t"<<"-O: output_dir: the directory to output the estimation result. Default: current directory"<<endl;
	cout<<"========================================"<<endl;
}

int main(int argc, char**argv)
{
	// parsing argument
	map<string,string> argu_parse_result = map<string,string>();
	map<string,string>::iterator argu_parse_iterator;

	try
	{
		int ch;
		opterr = 0;
		while((ch = getopt(argc,argv,"O:R:G:S:"))!= -1)
		{
			switch(ch)
			{
				case 'O': argu_parse_result["O"] = optarg; break;
				case 'R': argu_parse_result["R"] = optarg; break;
				case 'G': argu_parse_result["G"] = optarg; break;
				case 'S': argu_parse_result["S"] = optarg; break;
				case 'A': argu_parse_result["A"] = optarg; break;
			}
		}

		//post process of argument.
		//situation 1: -O is not specified.
		if( (argu_parse_iterator = argu_parse_result.find("O")) == argu_parse_result.end() )
		{
			argu_parse_result["O"] = "./";
		}
		else
		{
			argu_parse_result["O"] += "/";
			if( create_dir(argu_parse_result["O"]) == -1 )
			{
				throw runtime_error("mkdir error!\t");
			}
		}

		//situation 2: neithor of  -G or -R is specified: error
		if( (argu_parse_result.find("R") == argu_parse_result.end()) && (argu_parse_result.find("G") == argu_parse_result.end()) )
		{
			throw runtime_error("no annotation is specified.");
		}

		//situation 3: both of  -G and -R are specified: error
		if( (argu_parse_result.find("R") != argu_parse_result.end()) && (argu_parse_result.find("G") != argu_parse_result.end()) )
		{
			throw runtime_error("there are multiple annotation formats.");
		}
		//situation 4: -R is specified, but no refflat file.
		if( (argu_parse_result.find("R") != argu_parse_result.end()) )
		{
			ifstream tmp_in;
			tmp_in.open(argu_parse_result["R"].c_str());
			if(! tmp_in){
				throw runtime_error("can not open refflat file! Please check whether there exists the refflat file you specified.");
			}
		}
		//situation 5: -G is specified, but no gtf file.
		if( (argu_parse_result.find("G") != argu_parse_result.end()) )
		{
			ifstream tmp_in;
			tmp_in.open(argu_parse_result["G"].c_str());
			if(! tmp_in){
				throw runtime_error("can not open gtf file! Please check whether there exists the gtf file you specified.");
			}
		}
		

		//situation 6: -S is not specified: error
		if( argu_parse_result.find("S") == argu_parse_result.end() )
		{
			throw runtime_error("no mapping file is specified.");
		}
		else
		{
			ifstream tmp_in;
			tmp_in.open(argu_parse_result["S"].c_str());
			if(! tmp_in){
				throw runtime_error("can not open sam file! Please check whether there exists the sam file you specified.");
			}
		}
		
		// situation 7: -A is out of range.
		if( argu_parse_result.find("A") == argu_parse_result.end() )
		{
			argu_parse_result["A"] = "0.5"; // default: 0.5
		}
		else{
			double alpha = atof(argu_parse_result["A"].c_str());
			if(alpha > 1.0 || alpha < 0.0){
				throw runtime_error("illegal alpha. (alpha should be in [0, 1])");
			}
		}
	}
	catch(runtime_error err)
	{
		cerr<<"Exception catched:"<<"\t";
		cerr<<err.what()<<endl<<endl;
		usage();
		return 1;
	}

	time_t cur_time;
    time(&cur_time);
	stringstream ss (stringstream::in | stringstream::out);
    std_output_with_time(string("expression estimation start!\n"));

	clock_t start_time,end_time;
    start_time=clock();

	// try get file name
	int flag = 0;
	string sam_file_name = get_file_name(argu_parse_result["S"],flag);
	if(flag != 0){
		cerr<<"Invalid sam file name!"<<endl;
		return 1;
	}

	string str_out_nurd = argu_parse_result["O"] + sam_file_name;
    str_out_nurd += ".nurd";
	std_output_with_time("sam file:\t"+sam_file_name+"\n");

	string output_name=str_out_nurd+".all_expr";
	std_output_with_time("expression file:\t"+output_name+"\n");

    ofstream out_nurd;
	try{
		out_nurd.open(str_out_nurd.c_str());
		if(! out_nurd){
			throw runtime_error("can not open nurd file! Please check whether there exists the nurd file.");
		}
	}
	catch(runtime_error err){
		cerr<<"Exception catched:"<<"\t";
		cerr<<err.what()<<endl<<endl;
		return 1;
	}

	int annotype;// refflat is 1, GTF is 2
	string anno_name;

	if( argu_parse_result.find("R") != argu_parse_result.end() ) // refflat format
	{
		annotype = 1;
		anno_name = argu_parse_result["R"];
	}
	else // GTF
	{
		annotype = 2;
		anno_name = argu_parse_result["G"];
	}

	ifstream in_anno(anno_name.c_str());
    ifstream in_sam(argu_parse_result["S"].c_str());

	if( get_exon_read_count(in_anno,in_sam,out_nurd,true, annotype) == -1){
		cerr<<"the reads are not in the same length. Please make sure that all the reads have the same read length." << endl;
		return 1;
	}

	out_nurd.close();

	//expression estimation
	ifstream in_nurd;
	try{
		in_nurd.open(str_out_nurd.c_str());
		if(! in_nurd){
			throw runtime_error("can not open nurd file! Please check whether there exists the nurd file.");
		}
	}
	catch(runtime_error err){
		cerr<<"Exception catched:"<<"\t";
		cerr<<err.what()<<endl<<endl;
		return 1;
	}
	
	get_GBC_bin(in_nurd);
	
	ofstream out(output_name.c_str());

	double alpha = atof(argu_parse_result["A"].c_str());
	
	time_t esti_start, esti_end;
	esti_start = clock();
	calcuAllTheGenes(in_nurd, out, alpha);
	esti_end = clock();
    time(&cur_time);

	ss<<"expression estimation time:\t"<<((double)esti_end-esti_start)/CLOCKS_PER_SEC<<" seconds.\n";
    std_output_with_time(ss.str());
    ss.str("");

    ss<<"expression done!"<<endl;
    std_output_with_time(ss.str());
    ss.str("");

	end_time = clock();
    ss << "total time:\t" << ((double)end_time-start_time)/CLOCKS_PER_SEC << " seconds." <<endl;
    std_output_with_time(ss.str());
    ss.str("");

    return 0;
}
