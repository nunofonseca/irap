#ifndef MYFUNCTION_H_INCLUDED
#define MYFUNCTION_H_INCLUDED

#include <time.h>
#include <stdio.h>
#include <string>
#include <iostream>

#include <unistd.h> // parsing argument
#include <sys/stat.h> 	// mkdir and access 
#include <errno.h> 	// error information
#include <string.h>	// strerror

using namespace std;

bool std_output_with_time(string s);

string get_file_name(const string& dir, int& flag);

int create_dir(const string&  dirName);

#endif // MYFUNCTION_H_INCLUDED
