
#define BUFFER_DEFAULT 10000

bool transposeFiles(vector<string> inFileNames, string outFileName, bool verbose, string message = "");
