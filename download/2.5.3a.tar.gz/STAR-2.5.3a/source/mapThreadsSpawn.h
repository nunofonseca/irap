#ifndef CODE_mapThreadsSpawn
#define CODE_mapThreadsSpawn
#include "Parameters.h"
#include "ReadAlignChunk.h"
void mapThreadsSpawn (Parameters *P, ReadAlignChunk** RAchunk);

#endif