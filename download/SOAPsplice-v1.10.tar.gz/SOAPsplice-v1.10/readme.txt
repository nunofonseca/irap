This readme describes how to use the software SOAPsplice.
For more information about SOAPsplice, please refer to the website: http://soap.genomics.org.cn/soapsplice.html


-----------------------------------------------------------------------------------------------------------
Files:
./bin/: executable files.
./example/: example to use the software, you can just run the script "example.sh".
./doc/: document for users, it introduces the format of output files.


-----------------------------------------------------------------------------------------------------------
How to use SOAPsplice to do alignment (with DNA) for transcriptome

1. Build index for reference

% ./2bwt-builder <FASTA sequence file> <Output index prefix>

Example: % ./2bwt-builder humangenome.fa
      or % ./2bwt-builder humangenome.fa index/humangenome.fa # the index files will be in the directory "index/".

Note:
If you don't input "<Output index prefix>", a collection of files will be built with the filename prefix "<FASTA sequence file>.index", otherwise the prefix is "<Output index prefix>.index".


2. Do the alignment

% soapsplice -p <thread_number> -d <2BWT index prefix> -1 <reads_a> -2 <reads_b> -I <insert length of paired-end reads> -o <prefix of output files> [Advanced Options] 

Example: % soapsplice -p 1 -d hg18.fa.index -1 1.fq -2 2.fq -o ./test -I 200 

Note:
For the value of parameters, the value followed "-t" is the longest distance between two segments on the same chromosome (two segments belong to one read). For human, the recommended value is 500000, for arabidopsis, the recommended value is 1000. For "-m" and "-g", you can use the vaule in the example. For more information about SOAPsplice, please refer to the website: http://soap.genomics.org.cn/soapsplice.html

