#!/bin/bash

# This is an example for running SOAPsplice, including generating simulated data.

# Create two folders to put index of reference and the simulated data (short paired-end reads).
[ -d data ] || mkdir data
[ -d index ] || mkdir index

# Generate simulated reads, two files with short reads will be generated: "10X_50_1.fq" and "10X_50_2.fq" in folder "data".
# Here, "200" is the insert length, "10" is the depth of coverage, "50" is the length of the read.
../bin/wgsim exampleRNA.fa data/10X_50_1.fq data/10X_50_2.fq -d 200 -N 10 -1 50 -2 50

# Build index for genome sequence, a collect of files with prefix "exampleGenome.fa.index" will be generated in folder "index".
../bin/2bwt-builder exampleGenome.fa index/exampleGenome.fa 

# Do RNA alignment, four files will be generated: "example_1.fq.out", "example_1.fq.2Segs", "example_2.fq.out", "example_2.fq.2Segs", and "example.junc", all the output files are in the directory "out".
# And the output on the screen will be redirected to "10X_50.stdout" and "10X_50.stderr" respectively.
[ -d out ] || mkdir out
../bin/soapsplice -d index/exampleGenome.fa.index -1 data/10X_50_1.fq -2 data/10X_50_2.fq -o out/example -I 200 > data/10X_50.stdout 2> data/10X_50.stderr

exit 0
